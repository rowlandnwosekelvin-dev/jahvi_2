import json
import math
import os
import subprocess
import tempfile
from pathlib import Path


def _run_ffmpeg(command, error_message):
    result = subprocess.run(command, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or error_message)


def _video_duration(video_path):
    command = [
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "json", str(video_path),
    ]
    result = subprocess.run(command, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "Could not read video duration")
    duration = float(json.loads(result.stdout)["format"]["duration"])
    if not math.isfinite(duration) or duration <= 0:
        raise RuntimeError("Video duration is invalid")
    return duration


def _valid_timestamps(values, duration):
    try:
        cleaned = sorted({round(float(value), 3) for value in values})
    except (TypeError, ValueError):
        raise ValueError("Headshot timestamps must be numeric")
    if not cleaned or any(value < 0 or value >= duration for value in cleaned):
        raise ValueError("Headshot timestamps must be within the video duration")
    if any(not math.isfinite(value) for value in cleaned):
        raise ValueError("Headshot timestamps must be finite")
    return cleaned


def _pair_timestamps(headshots, beats):
    """Pair ordered headshots with beats, cycling footage for extra beats."""
    if not beats:
        raise ValueError("No usable beats were detected")
    if not headshots:
        raise ValueError("At least one headshot timestamp is required")

    repeated = []
    while len(repeated) < len(beats):
        repeated.extend(headshots)
    return list(zip(repeated, beats))


def _atempo_chain(speed):
    filters = []
    remaining = speed
    while remaining < 0.5:
        filters.append("atempo=0.5")
        remaining /= 0.5
    while remaining > 2.0:
        filters.append("atempo=2.0")
        remaining /= 2.0
    filters.append(f"atempo={remaining:.6f}")
    return ",".join(filters)


def _write_segment(video_path, start, end, target_duration, output_path):
    source_duration = end - start
    if source_duration <= 0.01 or target_duration <= 0.01:
        return False
    speed = source_duration / target_duration
    has_audio = _has_audio_stream(video_path)
    filter_graph = f"[0:v]setpts=PTS/{speed:.8f},trim=duration={target_duration:.3f},setpts=PTS-STARTPTS[v]"
    if has_audio:
        filter_graph += (
            f";[0:a]{_atempo_chain(speed)},atrim=duration={target_duration:.3f},"
            "asetpts=PTS-STARTPTS[a]"
        )
    command = [
        "ffmpeg", "-y", "-ss", f"{start:.3f}", "-i", str(video_path),
        "-t", f"{source_duration:.3f}", "-filter_complex", filter_graph,
        "-map", "[v]", "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p",
    ]
    if has_audio:
        command.extend(["-map", "[a]", "-c:a", "aac", "-ar", "48000", "-ac", "2", "-shortest"])
    else:
        command.append("-an")
    command.append(str(output_path))
    _run_ffmpeg(command, "Could not retime video segment")
    return True


def _has_audio_stream(video_path):
    result = subprocess.run(
        [
            "ffprobe", "-v", "error", "-select_streams", "a:0",
            "-show_entries", "stream=index", "-of", "csv=p=0", str(video_path),
        ],
        capture_output=True,
        text=True,
    )
    return result.returncode == 0 and bool(result.stdout.strip())


def _concat_segments(segment_paths, output_path, work_dir):
    list_path = Path(work_dir) / "concat.txt"
    list_path.write_text("".join(f"file '{path}'\n" for path in segment_paths), encoding="utf-8")
    _run_ffmpeg(
        ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(list_path),
         "-c", "copy", "-movflags", "+faststart", str(output_path)],
        "Could not concatenate synchronized video segments",
    )


def synchronize_video(video_path, headshot_timestamps, beat_timestamps, output_path):
    """Retimes the full video so each selected headshot lands on a beat."""
    duration = _video_duration(video_path)
    headshots = _valid_timestamps(headshot_timestamps, duration)
    try:
        beats = sorted({round(float(value), 3) for value in beat_timestamps})
    except (TypeError, ValueError):
        raise ValueError("Beat timestamps must be numeric")
    if any(not math.isfinite(value) or value < 0 for value in beats):
        raise ValueError("Beat timestamps must be finite and non-negative")
    pairs = _pair_timestamps(headshots, beats)
    work_dir = tempfile.mkdtemp(prefix="jahvi_sync_")
    segments = []

    try:
        source_cursor = 0.0
        output_cursor = 0.0
        for index, (headshot, beat) in enumerate(pairs):
            target_duration = beat - output_cursor
            if target_duration <= 0.01:
                continue
            segment_path = Path(work_dir) / f"segment_{index:04d}.mp4"
            if headshot > source_cursor:
                segment_start = source_cursor
                segment_end = headshot
            else:
                # Repeated beats reuse footage ending at the selected headshot.
                segment_end = headshot
                segment_start = max(0.0, segment_end - min(target_duration, duration))
            if _write_segment(video_path, segment_start, segment_end, target_duration, segment_path):
                segments.append(segment_path)
            if headshot > source_cursor:
                source_cursor = headshot
            output_cursor = beat

        if source_cursor < duration:
            tail_path = Path(work_dir) / "tail.mp4"
            if _write_segment(video_path, source_cursor, duration, duration - source_cursor, tail_path):
                segments.append(tail_path)

        if not segments:
            raise RuntimeError("No synchronized video segments were produced")
        _concat_segments(segments, output_path, work_dir)
    finally:
        for path in Path(work_dir).glob("*"):
            path.unlink(missing_ok=True)
        os.rmdir(work_dir)