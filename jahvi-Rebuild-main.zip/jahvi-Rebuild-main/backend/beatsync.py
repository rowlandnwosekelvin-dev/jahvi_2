import json
import os
import shutil
import subprocess
import tempfile
import uuid
from pathlib import Path
from typing import Iterator

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from fastapi.responses import StreamingResponse
from sqlalchemy import update
from sqlalchemy.orm import Session

from database import DashboardEffect, User, get_db
from dashboard import ALLOWED_RATIOS, OUTPUT_DIR, _apply_stage_2_effects, _pick_effect_for_user, _parse_timestamps
from me import get_current_user
from rms import detect_beats
from timestamp_sync import synchronize_video
from upload_limits import CREDIT_COST, require_processing_credits, save_upload_in_chunks

router = APIRouter(prefix="/api", tags=["beatsync"])
VIDEO_EXTENSIONS = {".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v", ".flv"}
AUDIO_EXTENSIONS = {".mp3", ".wav", ".flac", ".m4a", ".aac", ".ogg", ".opus"}


def _event(event, **data):
    return f"data: {json.dumps({'event': event, **data})}\n\n"


def _require_tools():
    missing = [name for name in ("ffmpeg", "ffprobe") if shutil.which(name) is None]
    if missing:
        raise HTTPException(status_code=503, detail=f"Missing video tools: {', '.join(missing)}")


def _save_upload(upload, directory, allowed_extensions):
    suffix = Path(upload.filename or "").suffix.lower()
    if suffix not in allowed_extensions:
        raise HTTPException(status_code=415, detail="Unsupported upload format")
    path = Path(directory) / f"{uuid.uuid4()}{suffix}"
    try:
        with path.open("wb") as output:
            while chunk := upload.file.read(1024 * 1024):
                output.write(chunk)
    except Exception:
        path.unlink(missing_ok=True)
        raise
    return path


def _extract_audio(source_path, output_path):
    result = subprocess.run(
        ["ffmpeg", "-y", "-i", str(source_path), "-vn", "-acodec", "libmp3lame", "-q:a", "2", str(output_path)],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "Could not extract audio")


def _has_audio_stream(video_path):
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=index", "-of", "csv=p=0", str(video_path)],
        capture_output=True,
        text=True,
    )
    return result.returncode == 0 and bool(result.stdout.strip())


def _mix_audio(video_path, music_path, volume, output_path):
    if _has_audio_stream(video_path):
        filter_graph = (
            f"[1:a]volume={volume:.3f}[music];"
            "[0:a][music]amix=inputs=2:duration=first:dropout_transition=2[a]"
        )
        command = [
            "ffmpeg", "-y", "-i", str(video_path), "-i", str(music_path),
            "-filter_complex", filter_graph, "-map", "0:v:0", "-map", "[a]",
            "-c:v", "copy", "-c:a", "aac", "-movflags", "+faststart", str(output_path),
        ]
    else:
        command = [
            "ffmpeg", "-y", "-i", str(video_path), "-i", str(music_path),
            "-filter_complex", f"[1:a]volume={volume:.3f}[a]",
            "-map", "0:v:0", "-map", "[a]", "-c:v", "copy", "-c:a", "aac",
            "-shortest", "-movflags", "+faststart", str(output_path),
        ]
    result = subprocess.run(command, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "Could not mix music")


@router.post("/beatsync")
def beatsync(
    video: UploadFile = File(...),
    custom_audio: UploadFile | None = File(None),
    headshot_timestamps: str = Form(...),
    effect_class_ids: str = Form(...),
    ratio: str = Form("9:16"),
    music_volume: float = Form(1.0),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    locked_user = require_processing_credits(db, user)
    _require_tools()
    if video.content_type and not video.content_type.startswith("video/"):
        raise HTTPException(status_code=415, detail="Please upload a video file")
    if ratio not in ALLOWED_RATIOS:
        raise HTTPException(status_code=422, detail="Unsupported export ratio")
    if not 0 <= music_volume <= 1:
        raise HTTPException(status_code=422, detail="Music volume must be between 0 and 1")
    timestamps = _parse_timestamps(headshot_timestamps)
    try:
        effect_ids = [int(value) for value in json.loads(effect_class_ids)]
    except (TypeError, ValueError, json.JSONDecodeError):
        raise HTTPException(status_code=422, detail="Selected effects must be a JSON array of ids")
    if not effect_ids:
        raise HTTPException(status_code=422, detail="Choose at least one effect style")

    request_dir = Path(tempfile.mkdtemp(prefix="jahvi_beatsync_"))
    paths = []
    try:
        source_path = save_upload_in_chunks(video, request_dir, VIDEO_EXTENSIONS, locked_user.plan)
        paths.append(source_path)
        if custom_audio is None and not _has_audio_stream(source_path):
            raise HTTPException(status_code=422, detail="The source video must contain an audio stream")
        music_source = source_path
        if custom_audio is not None:
            music_source = save_upload_in_chunks(custom_audio, request_dir, VIDEO_EXTENSIONS | AUDIO_EXTENSIONS, locked_user.plan)
            paths.append(music_source)
        effect = _pick_effect_for_user(db, locked_user, effect_ids)
        synced_path = request_dir / "synced.mp4"
        effected_path = request_dir / "effected.mp4"
        final_path = OUTPUT_DIR / f"{uuid.uuid4()}.mp4"
        paths.extend([synced_path, effected_path])

        def stream() -> Iterator[str]:
            completed = False
            try:
                yield _event("progress", percent=5, message="Video uploaded")

                analysis_audio = request_dir / "analysis.mp3"
                if music_source.suffix.lower() in VIDEO_EXTENSIONS:
                    _extract_audio(music_source, analysis_audio)
                    paths.append(analysis_audio)
                else:
                    analysis_audio = music_source
                beat_times = detect_beats(str(analysis_audio))
                if not beat_times:
                    raise ValueError("No usable beats were detected")
                yield _event("progress", percent=45, message=f"Detected {len(beat_times)} beats")

                synchronize_video(source_path, timestamps, beat_times, synced_path)
                yield _event("progress", percent=65, message="Headshots synchronized")

                _apply_stage_2_effects(
                    synced_path,
                    effected_path,
                    effect,
                    beat_times,
                    effect_duration=0.4,
                )
                yield _event("progress", percent=75, message="Effects applied")

                if custom_audio is not None:
                    music_path = request_dir / "music.mp3"
                    if music_source.suffix.lower() in VIDEO_EXTENSIONS:
                        _extract_audio(music_source, music_path)
                        paths.append(music_path)
                    else:
                        music_path = music_source
                    _mix_audio(effected_path, music_path, music_volume, final_path)
                else:
                    shutil.copyfile(effected_path, final_path)

                if not final_path.is_file() or final_path.stat().st_size == 0:
                    raise RuntimeError("Final video was not created")
                db.execute(update(User).where(User.id == locked_user.id, User.credits >= CREDIT_COST).values(credits=User.credits - CREDIT_COST))
                db.commit()
                completed = True
                yield _event("completed", percent=95, filename=final_path.name)
            except Exception as error:
                db.rollback()
                final_path.unlink(missing_ok=True)
                yield _event("error", message=str(error))
            finally:
                for path in paths:
                    path.unlink(missing_ok=True)
                request_dir.rmdir()
                if not completed:
                    final_path.unlink(missing_ok=True)

        return StreamingResponse(stream(), media_type="text/event-stream")
    except Exception:
        for path in paths:
            path.unlink(missing_ok=True)
        shutil.rmtree(request_dir, ignore_errors=True)
        raise