(() => {
  const state = { timestamps: [], duration: 0, activeIndex: -1, dragging: false };
  const track = document.getElementById('timelineTrack');
  const emptyLabel = document.getElementById('timelineEmpty');
  const addButton = document.getElementById('addBarBtn');
  const currentTimeLabel = document.getElementById('timelineCurrentTime');
  const video = document.getElementById('videoPreviewPlayer');
  const list = document.getElementById('timestampList');

  if (!track || !video) return;

  const emitChange = () => window.dispatchEvent(new CustomEvent('jahvi:timelinechange'));
  const clampTime = value => Math.max(0, Math.min(state.duration || 0, value));
  const formatTime = value => {
    const minutes = Math.floor(value / 60);
    const seconds = value - minutes * 60;
    return `${String(minutes).padStart(2, '0')}:${seconds.toFixed(2).padStart(5, '0')}`;
  };

  function render() {
    track.querySelectorAll('.timeline-bar').forEach(bar => bar.remove());
    if (emptyLabel) emptyLabel.style.display = state.timestamps.length ? 'none' : 'block';

    state.timestamps.forEach((timestamp, index) => {
      const bar = document.createElement('button');
      bar.type = 'button';
      bar.className = `timeline-bar${index === state.activeIndex ? ' active' : ''}`;
      bar.style.left = `${state.duration ? (timestamp / state.duration) * 100 : 0}%`;
      bar.title = `${timestamp.toFixed(2)}s`;
      bar.setAttribute('aria-label', `Headshot at ${timestamp.toFixed(2)} seconds`);
      bar.addEventListener('pointerdown', event => beginDrag(event, index));
      bar.addEventListener('click', () => {
        if (!bar.dataset.dragged) seekTo(state.timestamps[index]);
        delete bar.dataset.dragged;
      });
      track.appendChild(bar);
    });

    if (list) {
      list.replaceChildren();
      state.timestamps.forEach((timestamp, index) => {
        const item = document.createElement('li');
        item.className = `timestamp-item${index === state.activeIndex ? ' active' : ''}`;
        item.innerHTML = `<button type="button" class="timestamp-jump">${formatTime(timestamp)}</button><button type="button" class="timestamp-delete" aria-label="Delete headshot at ${formatTime(timestamp)}">×</button>`;
        item.querySelector('.timestamp-jump').addEventListener('click', () => seekTo(timestamp));
        item.querySelector('.timestamp-delete').addEventListener('click', () => {
          state.timestamps.splice(index, 1);
          state.activeIndex = -1;
          render();
          emitChange();
        });
        list.appendChild(item);
      });
    }
  }

  function seekTo(timestamp) {
    video.currentTime = clampTime(timestamp);
    video.pause();
    updateActive(video.currentTime);
  }

  function updateActive(currentTime) {
    currentTimeLabel.textContent = `${currentTime.toFixed(2)}s`;
    if (state.dragging) return;
    const nextIndex = state.timestamps.findIndex(timestamp => Math.abs(timestamp - currentTime) <= 0.12);
    if (nextIndex !== state.activeIndex) {
      state.activeIndex = nextIndex;
      render();
    }
  }

  function beginDrag(event, index) {
    event.preventDefault();
    const bar = event.currentTarget;
    const timestampItem = list?.children[index];
    let moved = false;
    state.dragging = true;
    bar.setPointerCapture(event.pointerId);
    const move = moveEvent => {
      const rect = track.getBoundingClientRect();
      const ratio = Math.max(0, Math.min(1, (moveEvent.clientX - rect.left) / rect.width));
      const timestamp = Number((ratio * state.duration).toFixed(2));
      moved = true;
      state.timestamps[index] = timestamp;
      video.currentTime = timestamp;
      state.activeIndex = index;
      bar.style.left = `${state.duration ? (timestamp / state.duration) * 100 : 0}%`;
      bar.title = `${timestamp.toFixed(2)}s`;
      bar.setAttribute('aria-label', `Headshot at ${timestamp.toFixed(2)} seconds`);
      if (timestampItem) {
        const jumpButton = timestampItem.querySelector('.timestamp-jump');
        const deleteButton = timestampItem.querySelector('.timestamp-delete');
        if (jumpButton) jumpButton.textContent = formatTime(timestamp);
        if (deleteButton) deleteButton.setAttribute('aria-label', `Delete headshot at ${formatTime(timestamp)}`);
        timestampItem.classList.add('active');
      }
      currentTimeLabel.textContent = `${timestamp.toFixed(2)}s`;
      bar.classList.add('active');
      emitChange();
    };
    const end = () => {
      bar.removeEventListener('pointermove', move);
      bar.removeEventListener('pointerup', end);
      bar.removeEventListener('pointercancel', end);
      if (bar.hasPointerCapture(event.pointerId)) bar.releasePointerCapture(event.pointerId);
      state.dragging = false;
      if (moved) {
        bar.dataset.dragged = 'true';
        render();
      }
    };
    bar.addEventListener('pointermove', move);
    bar.addEventListener('pointerup', end);
    bar.addEventListener('pointercancel', end);
  }

  addButton?.addEventListener('click', () => {
    if (!state.duration) return;
    const timestamp = Number(video.currentTime.toFixed(2));
    if (state.timestamps.some(existing => Math.abs(existing - timestamp) < 0.05)) return;
    state.timestamps.push(timestamp);
    state.timestamps.sort((a, b) => a - b);
    state.activeIndex = state.timestamps.indexOf(timestamp);
    render();
    emitChange();
  });

  video.addEventListener('loadedmetadata', () => {
    state.duration = Number.isFinite(video.duration) ? video.duration : 0;
    addButton.disabled = !state.duration;
    render();
  });
  video.addEventListener('timeupdate', () => updateActive(video.currentTime));
  video.addEventListener('seeking', () => updateActive(video.currentTime));

  window.JahviTimeline = {
    hasTimestamps: () => state.timestamps.length > 0,
    getTimestamps: () => [...state.timestamps],
    getDuration: () => state.duration,
    clear: () => { state.timestamps = []; state.activeIndex = -1; render(); emitChange(); },
  };
  render();
})();
